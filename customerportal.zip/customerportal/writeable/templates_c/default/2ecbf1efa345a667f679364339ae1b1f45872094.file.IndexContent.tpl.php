<?php /* Smarty version Smarty-3.1.19, created on 2021-06-30 01:52:57
         compiled from "/home4/kalpdeep/public_html/internalcrm/customerportal/layouts/default/templates/Products/partials/IndexContent.tpl" */ ?>
<?php /*%%SmartyHeaderCode:107187882460dc14c9c55c57-02107267%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '2ecbf1efa345a667f679364339ae1b1f45872094' => 
    array (
      0 => '/home4/kalpdeep/public_html/internalcrm/customerportal/layouts/default/templates/Products/partials/IndexContent.tpl',
      1 => 1587736809,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '107187882460dc14c9c55c57-02107267',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_60dc14c9d2d577_10589030',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_60dc14c9d2d577_10589030')) {function content_60dc14c9d2d577_10589030($_smarty_tpl) {?>

<?php echo $_smarty_tpl->getSubTemplate ("Portal/partials/IndexContent.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

<?php }} ?>
