<?php /* Smarty version Smarty-3.1.19, created on 2021-06-30 07:18:31
         compiled from "/home4/kalpdeep/public_html/internalcrm/customerportal/layouts/default/templates/Services/partials/IndexContent.tpl" */ ?>
<?php /*%%SmartyHeaderCode:59183316760dc611764cf56-58331285%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'b7447afb6ac2a7621931d7e0f913bc797c828422' => 
    array (
      0 => '/home4/kalpdeep/public_html/internalcrm/customerportal/layouts/default/templates/Services/partials/IndexContent.tpl',
      1 => 1587736809,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '59183316760dc611764cf56-58331285',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_60dc611770a6a4_35343457',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_60dc611770a6a4_35343457')) {function content_60dc611770a6a4_35343457($_smarty_tpl) {?>

<?php echo $_smarty_tpl->getSubTemplate ("Products/partials/IndexContent.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

<?php }} ?>
