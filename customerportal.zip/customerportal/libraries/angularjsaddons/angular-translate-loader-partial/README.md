# bower-angular-translate-loader-partial

angular-translate-loader-partial bower package

### Installation

````
$ bower install angular-translate-loader-partial
````
