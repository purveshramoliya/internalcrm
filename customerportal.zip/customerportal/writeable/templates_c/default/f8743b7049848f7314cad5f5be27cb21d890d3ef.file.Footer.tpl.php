<?php /* Smarty version Smarty-3.1.19, created on 2021-06-07 05:22:07
         compiled from "/home4/kalpdeep/public_html/internalcrm/customerportal/layouts/default/templates/Footer.tpl" */ ?>
<?php /*%%SmartyHeaderCode:137694885660bdf34fda7e55-66450750%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'f8743b7049848f7314cad5f5be27cb21d890d3ef' => 
    array (
      0 => '/home4/kalpdeep/public_html/internalcrm/customerportal/layouts/default/templates/Footer.tpl',
      1 => 1587736809,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '137694885660bdf34fda7e55-66450750',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.19',
  'unifunc' => 'content_60bdf34fda89f6_00707454',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_60bdf34fda89f6_00707454')) {function content_60bdf34fda89f6_00707454($_smarty_tpl) {?>

</div>
</body>
</html>
<?php }} ?>
