<html>
<head>
<title></title>
</head>
<form action='../../../../application/modules/default/views/scripts/emppayslips/submit.php?userid=<?php echo $this->id;?>' method='post'>
    <div class="new-form-ui-submit">
<input type='submit' name='submit' value='Generate Payslip'>
</div>
</form>
</body>
</html>